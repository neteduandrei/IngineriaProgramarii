import java.util.List;

public class FormServiceImpl implements CrudService {
    /**
     * @param entity <Enter note text here>
     */
    public T save(T entity) {
    }

    /**
     * <Enter note text here>
     */
    public List<T> getAll() {
    }

    public T getById(int Id) {
    }

    public void delete(int Id) {
    }

}
